// Configuration for Prettier
module.exports = {
  semi: true,
  trailingComma: 'es5',
  singleQuote: true,
  printWidth: 150,
  tabWidth: 2,
  endOfLine: 'lf',
};
