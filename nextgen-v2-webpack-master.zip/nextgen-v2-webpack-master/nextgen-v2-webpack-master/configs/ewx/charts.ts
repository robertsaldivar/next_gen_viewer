export const charts = [
  /**
   * Africa
   */
  // CHIRPS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalData',
        timeseriesSourceLayerIds: ['africaChirpsPentadalData'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'africaChirpsPentadalData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirpsPentadalPrelimData'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalGEFs5Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'africaChirpsPentadalData',
        timeseriesSourceLayerIds: ['africaChirpsPentadalGEFs5Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalGEFs10Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'africaChirpsPentadalData',
        timeseriesSourceLayerIds: ['africaChirpsPentadalGEFs10Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalGEFs15Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'africaChirpsPentadalData',
        timeseriesSourceLayerIds: ['africaChirpsPentadalGEFs15Data'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['africaChirpsPentadalAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalPrelimAnomaly',
        impersonate: 'africaChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['africaChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['africaChirpsPentadalZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalPrelimZscore',
        impersonate: 'africaChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['africaChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsMonthlyData',
        timeseriesSourceLayerIds: ['africaChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirpsMonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'africaChirpsMonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirpsMonthlyPrelimData'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsMonthlyAnomaly',
        timeseriesSourceLayerIds: ['africaChirpsMonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirpsMonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'africaChirpsMonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirpsMonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsMonthlyZscore',
        timeseriesSourceLayerIds: ['africaChirpsMonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirpsMonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'africaChirpsMonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirpsMonthlyPrelimZscore'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps2MonthlyData',
        timeseriesSourceLayerIds: ['africaChirps2MonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirps2MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'africaChirps2MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirps2MonthlyPrelimData'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps2MonthlyAnomaly',
        timeseriesSourceLayerIds: ['africaChirps2MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirps2MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'africaChirps2MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirps2MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps2MonthlyZscore',
        timeseriesSourceLayerIds: ['africaChirps2MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirps2MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'africaChirps2MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirps2MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps3MonthlyData',
        timeseriesSourceLayerIds: ['africaChirps3MonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirps3MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'africaChirps3MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirps3MonthlyPrelimData'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps3MonthlyAnomaly',
        timeseriesSourceLayerIds: ['africaChirps3MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirps3MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'africaChirps3MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirps3MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps3MonthlyZscore',
        timeseriesSourceLayerIds: ['africaChirps3MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'africaChirps3MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'africaChirps3MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirps3MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // CHIRPS Prelim
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      // only applicable if there is a mean for the periodicity
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalPrelimData',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'africaChirpsPentadalData',
        timeseriesSourceLayerIds: ['africaChirpsPentadalPrelimData'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        // dataType refers to the type of data we are requesting.
        dataType: 'annual_gefs',
        // dataRoot refers to the raster name in the config endpoint
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalPrelimAnomaly',
        impersonate: 'africaChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['africaChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsPentadalPrelimZscore',
        impersonate: 'africaChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['africaChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsMonthlyPrelimData',
        impersonate: 'africaChirpsMonthlyData',
        timeseriesSourceLayerIds: ['africaChirpsMonthlyPrelimData'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps-prelim_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsMonthlyPrelimAnomaly',
        impersonate: 'africaChirpsMonthlyAnomaly',
        timeseriesSourceLayerIds: ['africaChirpsMonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirpsMonthPrelimZscore',
        impersonate: 'africaChirpsMonthlyZscore',
        timeseriesSourceLayerIds: ['africaChirpsMonthPrelimZscore'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps2MonthPrelimData',
        impersonate: 'africaChirps2MonthlyData',
        timeseriesSourceLayerIds: 'africaChirps2MonthPrelimData',
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps2MonthPrelimAnomaly',
        impersonate: 'africaChirps2MonthlyAnomaly',
        timeseriesSourceLayerIds: 'africaChirps2MonthPrelimAnomaly',
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps2MonthPrelimZscore',
        impersonate: 'africaChirps2MonthlyZscore',
        timeseriesSourceLayerIds: 'africaChirps2MonthPrelimZscore',
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps3MonthPrelimData',
        impersonate: 'africaChirps3MonthlyData',
        timeseriesSourceLayerIds: 'africaChirps3MonthPrelimData',
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps3MonthPrelimAnomaly',
        impersonate: 'africaChirps3MonthlyAnomaly',
        timeseriesSourceLayerIds: 'africaChirps3MonthPrelimAnomaly',
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'africaChirps3MonthPrelimZscore',
        impersonate: 'africaChirps3MonthlyZscore',
        timeseriesSourceLayerIds: 'africaChirps3MonthPrelimZscore',
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // FLDAS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['fldas-runoff-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'africaFldasMonthlyData',
        timeseriesSourceLayerIds: ['africaFldasMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'africaPrelimFldasMonthlyData',
        impersonate: 'africaFldasMonthlyData',
        timeseriesSourceLayerIds: ['africaPrelimFldasMonthlyData'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'africaFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['africaFldasMonthlyAnom'],
      },
      {
        type: 'single',
        forLayerId: 'africaPrelimFldasMonthlyAnom',
        impersonate: 'africaFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['africaPrelimFldasMonthlyAnom'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // RFE2
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['rfe2-2000-2018_africa_dekad_mean'],
    },
    overlays: ['africaRfeDekadalData'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_cumulative',
        dataRoot: 'rfe2_africa_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaRfeDekadalAnomaly'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_cumulative',
        dataRoot: 'rfe2_africa_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaRfeDekadalZscore'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_dekad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_dekad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['rfe2-2000-2018_africa_month_mean'],
    },
    overlays: ['africaRfeMonthlyData'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_cumulative',
        dataRoot: 'rfe2_africa_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaRfeMonthlyAnomaly'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_cumulative',
        dataRoot: 'rfe2_africa_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaRfeMonthlyZscore'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['rfe2-2000-2018_africa_2month_mean'],
    },
    overlays: ['africaRfe2MonthlyData'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_cumulative',
        dataRoot: 'rfe2_africa_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaRfe2MonthlyAnomaly'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_cumulative',
        dataRoot: 'rfe2_africa_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaRfe2MonthlyZscore'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['rfe2-2000-2018_africa_3month_mean'],
    },
    overlays: ['africaRfe3MonthlyData'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_cumulative',
        dataRoot: 'rfe2_africa_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaRfe3MonthlyAnomaly'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_cumulative',
        dataRoot: 'rfe2_africa_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaRfe3MonthlyZscore'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'rfe2_africa_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'rfe2_africa_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // LST_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_dekad_mean'],
    },
    overlays: ['africaLstC6DekadalData'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaLstC6DekadalAnomaly'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaLstC6DekadalZscore'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_month_mean'],
    },
    overlays: ['africaLstC6MonthlyData'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaLstC6MonthlyAnomaly'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaLstC6MonthlyZscore'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_2month_mean'],
    },
    overlays: ['africaLstC62MonthlyData'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaLstC62MonthlyAnomaly'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaLstC62MonthlyZscore'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_3month_mean'],
    },
    overlays: ['africaLstC63MonthlyData'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaLstC63MonthlyAnomaly'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['africaLstC63MonthlyZscore'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // NDVI_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['emodisndvic6v2-2003-2017_africa_dekad_median'],
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_africa_dekad_data'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_africa_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_africa_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_africa_dekad_anom'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_africa_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_africa_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['emodisndvic6v2_africa_dekad_pctn'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_africa_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_africa_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // EVIIRS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['eviirsndvi-2012-2021_africa_pentad_mean'],
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_africa_pentad_data'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_africa_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_africa_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_africa_pentad_anom'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_africa_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_africa_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['eviirsndvi_africa_pentad_pctm'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_africa_pentad_pctm.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_africa_pentad_pctm.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // Soil Moisture
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-10cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'africaSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['africaSoilMoisture10cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'africaSoilMoisturePrelim10cmMonthlyData',
        impersonate: 'africaSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['africaSoilMoisturePrelim10cmMonthlyData'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-100cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'africaSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['africaSoilMoisture100cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'africaSoilMoisturePrelim100cmMonthlyData',
        impersonate: 'africaSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['africaSoilMoisturePrelim100cmMonthlyData'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'africaSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['africaSoilMoisture10cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'africaSoilMoisturePrelim10cmMonthlyAnomaly',
        impersonate: 'africaSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['africaSoilMoisturePrelim10cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'africaSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['africaSoilMoisture100cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'africaSoilMoisturePrelim100cmMonthlyAnomaly',
        impersonate: 'africaSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['africaSoilMoisturePrelim100cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'africaSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['africaSoilMoisture10cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'africaSoilMoisturePrelim10cmMonthlyPctn',
        impersonate: 'africaSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['africaSoilMoisturePrelim10cmMonthlyPctn'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'africaSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['africaSoilMoisture100cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'africaSoilMoisturePrelim100cmMonthlyPctn',
        impersonate: 'africaSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['africaSoilMoisturePrelim100cmMonthlyPctn'],
      },
    ],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // ETA
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_dekad_median'],
    },
    overlays: ['africaEtaDekadalData'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['africaEtaDekadalPctn'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_month_median'],
    },
    overlays: ['africaEtaMonthlyData'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['africaEtaMonthlyPctn'],
    boundaries: ['africaAdmin1', 'africaAdmin2', 'africaCropzones', 'africaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  /**
   * Central America & Caribbean
   */
  // CHIRPS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalData',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalData'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalPrelimData',
        impersonate: 'camcarChirpsPentadalData',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalPrelimData'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalGEFs5Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'camcarChirpsPentadalData',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalGEFs5Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalGEFs10Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'camcarChirpsPentadalData',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalGEFs10Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalGEFs15Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'camcarChirpsPentadalData',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalGEFs15Data'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalPrelimAnomaly',
        impersonate: 'camcarChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalPrelimZscore',
        impersonate: 'camcarChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsMonthlyData',
        timeseriesSourceLayerIds: ['camcarChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsMonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'camcarChirpsMonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['camcarChirpsMonthlyPrelimData'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsMonthlyAnomaly',
        timeseriesSourceLayerIds: ['camcarChirpsMonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'acamcarhirpsMonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'camcarChirpsMonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['camcarChirpsMonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsMonthlyZscore',
        timeseriesSourceLayerIds: ['camcarChirpsMonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsMonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'camcarChirpsMonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['camcarChirpsMonthlyPrelimZscore'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps2MonthlyData',
        timeseriesSourceLayerIds: ['camcarChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirps2MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'camcarChirps2MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['camcarChirps2MonthlyPrelimData'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps2MonthlyAnomaly',
        timeseriesSourceLayerIds: ['camcarChirps2MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirps2MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'camcarChirps2MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['camcarChirps2MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps2MonthlyZscore',
        timeseriesSourceLayerIds: ['camcarChirps2MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirps2MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'camcarChirps2MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['camcarChirps2MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps3MonthlyData',
        timeseriesSourceLayerIds: ['camcarChirps3MonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirps3MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'camcarChirps3MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['camcarChirps3MonthlyPrelimData'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps3MonthlyAnomaly',
        timeseriesSourceLayerIds: ['camcarChirps3MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirps3MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'camcarChirps3MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['camcarChirps3MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps3MonthlyZscore',
        timeseriesSourceLayerIds: ['camcarChirps3MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'camcarChirps3MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'camcarChirps3MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['camcarChirps3MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // CHIRPS Prelim
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      // only applicable if there is a mean for the periodicity
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalPrelimData',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'camcarChirpsPentadalData',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalPrelimData'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        // dataType refers to the type of data we are requesting.
        dataType: 'annual_gefs',
        // dataRoot refers to the raster name in the config endpoint
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalPrelimAnomaly',
        impersonate: 'camcarChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsPentadalPrelimZscore',
        impersonate: 'camcarChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['camcarChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsMonthPrelimData',
        impersonate: 'camcarChirpsMonthData',
        timeseriesSourceLayerIds: ['camcarChirpsMonthPrelimData'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsMonthPrelimAnomaly',
        impersonate: 'camcarChirpsMonthAnomaly',
        timeseriesSourceLayerIds: ['camcarChirpsMonthPrelimAnomaly'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirpsMonthPrelimZscore',
        impersonate: 'camcarChirpsMonthZscore',
        timeseriesSourceLayerIds: ['camcarChirpsMonthPrelimZscore'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps2MonthPrelimData',
        impersonate: 'camcarChirps2MonthData',
        timeseriesSourceLayerIds: 'camcarChirps2MonthPrelimData',
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps2MonthPrelimAnomaly',
        impersonate: 'camcarChirps2MonthAnomaly',
        timeseriesSourceLayerIds: 'camcarChirps2MonthPrelimAnomaly',
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps2MonthPrelimZscore',
        impersonate: 'camcarChirps2MonthZscore',
        timeseriesSourceLayerIds: 'camcarChirps2MonthPrelimZscore',
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps3MonthPrelimData',
        impersonate: 'camcarChirps3MonthData',
        timeseriesSourceLayerIds: 'camcarChirps3MonthPrelimData',
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps3MonthPrelimAnomaly',
        impersonate: 'camcarChirps3MonthAnomaly',
        timeseriesSourceLayerIds: 'camcarChirps3MonthPrelimAnomaly',
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'camcarChirps3MonthPrelimZscore',
        impersonate: 'camcarChirps3MonthZscore',
        timeseriesSourceLayerIds: 'camcarChirps3MonthPrelimZscore',
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // FLDAS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['fldas-runoff-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'camcarFldasMonthlyData',
        timeseriesSourceLayerIds: ['camcarFldasMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'camcarPrelimFldasMonthlyData',
        impersonate: 'camcarFldasMonthlyData',
        timeseriesSourceLayerIds: ['camcarPrelimFldasMonthlyData'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'camcarFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['camcarFldasMonthlyAnom'],
      },
      {
        type: 'single',
        forLayerId: 'camcarPrelimFldasMonthlyAnom',
        impersonate: 'camcarFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['camcarPrelimFldasMonthlyAnom'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // LST_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_dekad_mean'],
    },
    overlays: ['camcarLstC6DekadalData'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['camcarLstC6DekadalAnomaly'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['camcarLstC6DekadalZscore'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_month_mean'],
    },
    overlays: ['camcarLstC6MonthlyData'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['camcarLstC6MonthlyAnomaly'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['camcarLstC6MonthlyZscore'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_2month_mean'],
    },
    overlays: ['camcarLstC62MonthlyData'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['camcarLstC62MonthlyAnomaly'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['camcarLstC62MonthlyZscore'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_3month_mean'],
    },
    overlays: ['camcarLstC63MonthlyData'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['camcarLstC63MonthlyAnomaly'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['camcarLstC63MonthlyZscore'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // NDVI_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['emodisndvic6v2-2003-2017_camcar_dekad_median'],
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_camcar_dekad_data'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_camcar_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_camcar_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_camcar_dekad_anom'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_camcar_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_camcar_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['emodisndvic6v2_camcar_dekad_pctn'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_camcar_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_camcar_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // EVIIRS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['eviirsndvi-2012-2021_camcar_pentad_mean'],
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_camcar_pentad_data'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_camcar_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_camcar_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_camcar_pentad_anom'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_camcar_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_camcar_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['eviirsndvi_camcar_pentad_pctm'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_camcar_pentad_pctm.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_camcar_pentad_pctm.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // Soil Moisture
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-10cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['camcarSoilMoisture10cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisturePrelim10cmMonthlyData',
        impersonate: 'camcarSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['camcarSoilMoisturePrelim10cmMonthlyData'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-100cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['camcarSoilMoisture100cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisturePrelim100cmMonthlyData',
        impersonate: 'camcarSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['camcarSoilMoisturePrelim100cmMonthlyData'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['camcarSoilMoisture10cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisturePrelim10cmMonthlyAnomaly',
        impersonate: 'camcarSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['camcarSoilMoisturePrelim10cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['camcarSoilMoisture100cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisturePrelim100cmMonthlyAnomaly',
        impersonate: 'camcarSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['camcarSoilMoisturePrelim100cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['camcarSoilMoisture10cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisturePrelim10cmMonthlyPctn',
        impersonate: 'camcarSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['camcarSoilMoisturePrelim10cmMonthlyPctn'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['camcarSoilMoisture100cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'camcarSoilMoisturePrelim100cmMonthlyPctn',
        impersonate: 'camcarSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['camcarSoilMoisturePrelim100cmMonthlyPctn'],
      },
    ],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // ETA
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_dekad_median'],
    },
    overlays: ['camcarEtaDekadalData'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['camcarEtaDekadalPctn'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_month_median'],
    },
    overlays: ['camcarEtaMonthlyData'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzones', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['camcarEtaMonthlyPctn'],
    boundaries: ['camcarAdmin1', 'camcarAdmin2', 'camcarCropzonesLoadOnly', 'camcarFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  /**
   * Central Asia
   */
  // CHIRPS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalData',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalData'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalPrelimData',
        impersonate: 'casiaChirpsPentadalData',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalPrelimData'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalGEFs5Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'casiaChirpsPentadalData',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalGEFs5Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalGEFs10Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'casiaChirpsPentadalData',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalGEFs10Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalGEFs15Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'casiaChirpsPentadalData',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalGEFs15Data'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalPrelimAnomaly',
        impersonate: 'casiaChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalPrelimZscore',
        impersonate: 'casiaChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsMonthlyData',
        timeseriesSourceLayerIds: ['casiaChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsMonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'casiaChirpsMonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['casiaChirpsMonthlyPrelimData'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsMonthlyAnomaly',
        timeseriesSourceLayerIds: ['casiaChirpsMonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsMonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'casiaChirpsMonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['casiaChirpsMonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsMonthlyZscore',
        timeseriesSourceLayerIds: ['casiaChirpsMonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsMonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'casiaChirpsMonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['casiaChirpsMonthlyPrelimZscore'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps2MonthlyData',
        timeseriesSourceLayerIds: ['casiaChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirps2MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'casiaChirps2MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['casiaChirps2MonthlyPrelimData'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps2MonthlyAnomaly',
        timeseriesSourceLayerIds: ['casiaChirps2MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirps2MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'casiaChirps2MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['casiaChirps2MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps2MonthlyZscore',
        timeseriesSourceLayerIds: ['casiaChirps2MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirps2MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'casiaChirps2MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['casiaChirps2MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps3MonthlyData',
        timeseriesSourceLayerIds: ['casiaChirps3MonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirps3MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'casiaChirps3MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['casiaChirps3MonthlyPrelimData'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps3MonthlyAnomaly',
        timeseriesSourceLayerIds: ['casiaChirps3MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirps3MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'casiaChirps3MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['casiaChirps3MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps3MonthlyZscore',
        timeseriesSourceLayerIds: ['casiaChirps3MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'casiaChirps3MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'casiaChirps3MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['africaChirps3MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // CHIRPS Prelim
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      // only applicable if there is a mean for the periodicity
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalPrelimData',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'casiaChirpsPentadalData',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalPrelimData'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        // dataType refers to the type of data we are requesting.
        dataType: 'annual_gefs',
        // dataRoot refers to the raster name in the config endpoint
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalPrelimAnomaly',
        impersonate: 'casiaChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsPentadalPrelimZscore',
        impersonate: 'casiaChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['casiaChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsMonthPrelimData',
        impersonate: 'casiaChirpsMonthData',
        timeseriesSourceLayerIds: ['casiaChirpsMonthPrelimData'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsMonthPrelimAnomaly',
        impersonate: 'casiaChirpsMonthAnomaly',
        timeseriesSourceLayerIds: ['casiaChirpsMonthPrelimAnomaly'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirpsMonthPrelimZscore',
        impersonate: 'casiaChirpsMonthZscore',
        timeseriesSourceLayerIds: ['casiaChirpsMonthPrelimZscore'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps2MonthPrelimData',
        impersonate: 'casiaChirps2MonthData',
        timeseriesSourceLayerIds: 'casiaChirps2MonthPrelimData',
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps2MonthPrelimAnomaly',
        impersonate: 'casiaChirps2MonthAnomaly',
        timeseriesSourceLayerIds: 'casiaChirps2MonthPrelimAnomaly',
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps2MonthPrelimZscore',
        impersonate: 'casiaChirps2MonthZscore',
        timeseriesSourceLayerIds: 'casiaChirps2MonthPrelimZscore',
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps3MonthPrelimData',
        impersonate: 'casiaChirps3MonthData',
        timeseriesSourceLayerIds: 'casiaChirps3MonthPrelimData',
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps3MonthPrelimAnomaly',
        impersonate: 'casiaChirps3MonthAnomaly',
        timeseriesSourceLayerIds: 'casiaChirps3MonthPrelimAnomaly',
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'casiaChirps3MonthPrelimZscore',
        impersonate: 'casiaChirps3MonthZscore',
        timeseriesSourceLayerIds: 'casiaChirps3MonthPrelimZscore',
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // FLDAS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['fldas-runoff-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'casiaFldasMonthlyData',
        timeseriesSourceLayerIds: ['casiaFldasMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'casiaPrelimFldasMonthlyData',
        impersonate: 'casiaFldasMonthlyData',
        timeseriesSourceLayerIds: ['casiaPrelimFldasMonthlyData'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'casiaFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['casiaFldasMonthlyAnom'],
      },
      {
        type: 'single',
        forLayerId: 'casiaPrelimFldasMonthlyAnom',
        impersonate: 'casiaFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['casiaPrelimFldasMonthlyAnom'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // LST_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_dekad_mean'],
    },
    overlays: ['casiaLstC6DekadalData'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['casiaLstC6DekadalAnomaly'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['casiaLstC6DekadalZscore'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_month_mean'],
    },
    overlays: ['casiaLstC6MonthlyData'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['casiaLstC6MonthlyAnomaly'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['casiaLstC6MonthlyZscore'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_2month_mean'],
    },
    overlays: ['casiaLstC62MonthlyData'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['casiaLstC62MonthlyAnomaly'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['casiaLstC62MonthlyZscore'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_3month_mean'],
    },
    overlays: ['casiaLstC63MonthlyData'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['casiaLstC63MonthlyAnomaly'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['casiaLstC63MonthlyZscore'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // NDVI_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['emodisndvic6v2-2003-2017_asia_dekad_median'],
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_asia_dekad_data'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_asia_dekad_anom'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['emodisndvic6v2_asia_dekad_pctn'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // NDVI_C6 Afghan IR
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['emodisndvic6v2-2003-2017_asia_dekad_median'],
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_asia_dekad_data'],
    boundaries: ['casiaAfghanIr'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_ir1000:shapefile_afghan_ir1000'],
    boundaryLabels: ['Afghanistan Irrigated'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_asia_dekad_anom'],
    boundaries: ['casiaAfghanIr'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_ir1000:shapefile_afghan_ir1000'],
    boundaryLabels: ['Afghanistan Irrigated'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['emodisndvic6v2_asia_dekad_pctn'],
    boundaries: ['casiaAfghanIr'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_ir1000:shapefile_afghan_ir1000'],
    boundaryLabels: ['Afghanistan Irrigated'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // NDVI_C6 Afghan RF
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['emodisndvic6v2-2003-2017_asia_dekad_median'],
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_asia_dekad_data'],
    boundaries: ['casiaAfghanRf'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rf1000:shapefile_afghan_rf1000'],
    boundaryLabels: ['Afghanistan Rainfed'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_asia_dekad_anom'],
    boundaries: ['casiaAfghanRf'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rf1000:shapefile_afghan_rf1000'],
    boundaryLabels: ['Afghanistan Rainfed'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['emodisndvic6v2_asia_dekad_pctn'],
    boundaries: ['casiaAfghanRf'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rf1000:shapefile_afghan_rf1000'],
    boundaryLabels: ['Afghanistan Rainfed'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // NDVI_C6 Afghan RG
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['emodisndvic6v2-2003-2017_asia_dekad_median'],
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_asia_dekad_data'],
    boundaries: ['casiaAfghanRg'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rg1000:shapefile_afghan_rg1000'],
    boundaryLabels: ['Afghanistan Rangeland'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_asia_dekad_anom'],
    boundaries: ['casiaAfghanRg'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rg1000:shapefile_afghan_rg1000'],
    boundaryLabels: ['Afghanistan Rangeland'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['emodisndvic6v2_asia_dekad_pctn'],
    boundaries: ['casiaAfghanRg'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rg1000:shapefile_afghan_rg1000'],
    boundaryLabels: ['Afghanistan Rangeland'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // EVIIRS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['eviirsndvi-2012-2021_asia_pentad_mean'],
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_asia_pentad_data'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_asia_pentad_anom'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['eviirsndvi_asia_pentad_pctm'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_pctm.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_pctm.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // EVIIRS Afghan IR
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['eviirsndvi-2012-2021_asia_pentad_mean'],
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_asia_pentad_data'],
    boundaries: ['casiaAfghanIr'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_ir1000:shapefile_afghan_ir1000'],
    boundaryLabels: ['Afghanistan Irrigated'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_asia_pentad_anom'],
    boundaries: ['casiaAfghanIr'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_ir1000:shapefile_afghan_ir1000'],
    boundaryLabels: ['Afghanistan Irrigated'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['eviirsndvi_asia_pentad_pctm'],
    boundaries: ['casiaAfghanIr'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_ir1000:shapefile_afghan_ir1000'],
    boundaryLabels: ['Afghanistan Irrigated'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_pctm.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_pctm.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // EVIIRS Afghan RF
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['eviirsndvi-2012-2021_asia_pentad_mean'],
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_asia_pentad_data'],
    boundaries: ['casiaAfghanRf'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rf1000:shapefile_afghan_rf1000'],
    boundaryLabels: ['Afghanistan Rainfed'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_asia_pentad_anom'],
    boundaries: ['casiaAfghanRf'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rf1000:shapefile_afghan_rf1000'],
    boundaryLabels: ['Afghanistan Rainfed'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['eviirsndvi_asia_pentad_pctm'],
    boundaries: ['casiaAfghanRf'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rf1000:shapefile_afghan_rf1000'],
    boundaryLabels: ['Afghanistan Rainfed'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_pctm.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_pctm.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // EVIIRS Afghan RG
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['eviirsndvi-2012-2021_asia_pentad_mean'],
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_asia_pentad_data'],
    boundaries: ['casiaAfghanRg'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rg1000:shapefile_afghan_rg1000'],
    boundaryLabels: ['Afghanistan Rangeland'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_asia_pentad_anom'],
    boundaries: ['casiaAfghanRg'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rg1000:shapefile_afghan_rg1000'],
    boundaryLabels: ['Afghanistan Rangeland'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['eviirsndvi_asia_pentad_pctm'],
    boundaries: ['casiaAfghanRg'],
    geoengineBoundaryNames: ['fews_shapefile_afghan_rg1000:shapefile_afghan_rg1000'],
    boundaryLabels: ['Afghanistan Rangeland'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_pctm.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_pctm.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // SWE
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/sum/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSnowData',
    },
    overlays: ['afghanbasinsSWEDailyData'],
    boundaries: ['afghanBasins', 'casiaAfghanDam'],
    boundaryLabels: ['Basins', 'Dams'],
    chartTypes: [
      {
        graphTypes: ['line'],
        dataType: 'minmax',
        dataRoot: 'swe_asia_day_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/sum/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSnowData',
    },
    overlays: ['afghanbasinsSWEDailyData'],
    boundaries: ['casiaPakistanBasins'],
    boundaryLabels: ['Pakistan Basins'],
    chartTypes: [
      {
        graphTypes: ['line'],
        dataType: 'minmax',
        dataRoot: 'swe_asia_day_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/sum/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSnowData',
    },
    overlays: ['afghanbasinsSWEDailyData'],
    boundaries: ['casiaTajikistanBasins'],
    boundaryLabels: ['Tajikistan Basins'],
    chartTypes: [
      {
        graphTypes: ['line'],
        dataType: 'minmax',
        dataRoot: 'swe_asia_day_data.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // Soil Moisture
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-10cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['casiaSoilMoisture10cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisturePrelim10cmMonthlyData',
        impersonate: 'casiaSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['casiaSoilMoisturePrelim10cmMonthlyData'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-100cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['casiaSoilMoisture100cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisturePrelim100cmMonthlyData',
        impersonate: 'casiaSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['casiaSoilMoisturePrelim100cmMonthlyData'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['casiaSoilMoisture10cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisturePrelim10cmMonthlyAnomaly',
        impersonate: 'casiaSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['casiaSoilMoisturePrelim10cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['casiaSoilMoisture100cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisturePrelim100cmMonthlyAnomaly',
        impersonate: 'casiaSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['casiaSoilMoisturePrelim100cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['casiaSoilMoisture10cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisturePrelim10cmMonthlyPctn',
        impersonate: 'casiaSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['casiaSoilMoisturePrelim10cmMonthlyPctn'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['casiaSoilMoisture100cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'casiaSoilMoisturePrelim100cmMonthlyPctn',
        impersonate: 'casiaSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['casiaSoilMoisturePrelim100cmMonthlyPctn'],
      },
    ],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // ETA
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_dekad_median'],
    },
    overlays: ['casiaEtaDekadalData'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['casiaEtaDekadalPctn'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_month_median'],
    },
    overlays: ['casiaEtaMonthlyData'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaCropzones', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['casiaEtaMonthlyPctn'],
    boundaries: ['casiaAdmin1', 'casiaAdmin2', 'casiaFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  /**
   * Central Indo-Pacific
   */
  // CHIRPS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalData',
        timeseriesSourceLayerIds: ['cipChirpsPentadalData'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'cipChirpsPentadalData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['cipChirpsPentadalPrelimData'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalGEFs5Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'cipChirpsPentadalData',
        timeseriesSourceLayerIds: ['cipChirpsPentadalGEFs5Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalGEFs10Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'cipChirpsPentadalData',
        timeseriesSourceLayerIds: ['cipChirpsPentadalGEFs10Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalGEFs15Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'cipChirpsPentadalData',
        timeseriesSourceLayerIds: ['cipChirpsPentadalGEFs15Data'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['cipChirpsPentadalAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalPrelimAnomaly',
        impersonate: 'cipChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['cipChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['cipChirpsPentadalZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalPrelimZscore',
        impersonate: 'cipChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['cipChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsMonthlyData',
        timeseriesSourceLayerIds: ['cipChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirpsMonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'cipChirpsMonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['cipChirpsMonthlyPrelimData'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsMonthlyAnomaly',
        timeseriesSourceLayerIds: ['cipChirpsMonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirpsMonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'cipChirpsMonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['cipChirpsMonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsMonthlyZscore',
        timeseriesSourceLayerIds: ['cipChirpsMonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirpsMonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'cipChirpsMonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['cipChirpsMonthlyPrelimZscore'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps2MonthlyData',
        timeseriesSourceLayerIds: ['cipChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirps2MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'cipChirps2MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['cipChirps2MonthlyPrelimData'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps2MonthlyAnomaly',
        timeseriesSourceLayerIds: ['cipChirps2MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirps2MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'cipChirps2MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['cipChirps2MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps2MonthlyZscore',
        timeseriesSourceLayerIds: ['cipChirps2MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirps2MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'cipChirps2MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['cipChirps2MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps3MonthlyData',
        timeseriesSourceLayerIds: ['cipChirps3MonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirps3MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'cipChirps3MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['cipChirps3MonthlyPrelimData'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps3MonthlyAnomaly',
        timeseriesSourceLayerIds: ['cipChirps3MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirps3MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'cipChirps3MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['cipChirps3MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps3MonthlyZscore',
        timeseriesSourceLayerIds: ['cipChirps3MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'cipChirps3MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'cipChirps3MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['cipChirps3MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // CHIRPS Prelim
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      // only applicable if there is a mean for the periodicity
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalPrelimData',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'cipChirpsPentadalData',
        timeseriesSourceLayerIds: ['cipChirpsPentadalPrelimData'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        // dataType refers to the type of data we are requesting.
        dataType: 'annual_gefs',
        // dataRoot refers to the raster name in the config endpoint
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalPrelimAnomaly',
        impersonate: 'cipChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['cipChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsPentadalPrelimZscore',
        impersonate: 'cipChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['cipChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsMonthPrelimData',
        impersonate: 'cipChirpsMonthData',
        timeseriesSourceLayerIds: ['cipChirpsMonthPrelimData'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsMonthPrelimAnomaly',
        impersonate: 'cipChirpsMonthAnomaly',
        timeseriesSourceLayerIds: ['cipChirpsMonthPrelimAnomaly'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirpsMonthPrelimZscore',
        impersonate: 'cipChirpsMonthZscore',
        timeseriesSourceLayerIds: ['cipChirpsMonthPrelimZscore'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps2MonthPrelimData',
        impersonate: 'cipChirps2MonthData',
        timeseriesSourceLayerIds: 'cipChirps2MonthPrelimData',
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps2MonthPrelimAnomaly',
        impersonate: 'cipChirps2MonthAnomaly',
        timeseriesSourceLayerIds: 'cipChirps2MonthPrelimAnomaly',
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps2MonthPrelimZscore',
        impersonate: 'cipChirps2MonthZscore',
        timeseriesSourceLayerIds: 'cipChirps2MonthPrelimZscore',
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps3MonthPrelimData',
        impersonate: 'cipChirps3MonthData',
        timeseriesSourceLayerIds: 'cipChirps3MonthPrelimData',
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps3MonthPrelimAnomaly',
        impersonate: 'cipChirps3MonthAnomaly',
        timeseriesSourceLayerIds: 'cipChirps3MonthPrelimAnomaly',
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'cipChirps3MonthPrelimZscore',
        impersonate: 'cipChirps3MonthZscore',
        timeseriesSourceLayerIds: 'cipChirps3MonthPrelimZscore',
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // FLDAS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['fldas-runoff-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'cipFldasMonthlyData',
        timeseriesSourceLayerIds: ['cipFldasMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'cipPrelimFldasMonthlyData',
        impersonate: 'cipFldasMonthlyData',
        timeseriesSourceLayerIds: ['cipPrelimFldasMonthlyData'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'cipFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['cipFldasMonthlyAnom'],
      },
      {
        type: 'single',
        forLayerId: 'cipPrelimFldasMonthlyAnom',
        impersonate: 'cipFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['cipPrelimFldasMonthlyAnom'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // LST_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_dekad_mean'],
    },
    overlays: ['cipLstC6DekadalData'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['cipLstC6DekadalAnomaly'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['cipLstC6DekadalZscore'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_month_mean'],
    },
    overlays: ['cipLstC6MonthlyData'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['cipLstC6MonthlyAnomaly'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['cipLstC6MonthlyZscore'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_2month_mean'],
    },
    overlays: ['cipLstC62MonthlyData'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['cipLstC62MonthlyAnomaly'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['cipLstC62MonthlyZscore'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_3month_mean'],
    },
    overlays: ['cipLstC63MonthlyData'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['cipLstC63MonthlyAnomaly'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['cipLstC63MonthlyZscore'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // NDVI_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['emodisndvic6v2-2003-2017_centralindopacific_dekad_median'],
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_centralindopacific_dekad_data'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_centralindopacific_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_centralindopacific_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_centralindopacific_dekad_anom'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_centralindopacific_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_centralindopacific_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['emodisndvic6v2_centralindopacific_dekad_pctn'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_centralindopacific_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_centralindopacific_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // EVIIRS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['eviirsndvi-2012-2021_centralindopacific_pentad_mean'],
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_centralindopacific_pentad_data'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_centralindopacific_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_centralindopacific_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_centralindopacific_pentad_anom'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_centralindopacific_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_centralindopacific_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['eviirsndvi_centralindopacific_pentad_pctm'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_centralindopacific_pentad_pctm.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_centralindopacific_pentad_pctm.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // Soil Moisture
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-10cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'cipSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['cipSoilMoisture10cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'cipSoilMoisturePrelim10cmMonthlyData',
        impersonate: 'cipSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['cipSoilMoisturePrelim10cmMonthlyData'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-100cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'cipSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['cipSoilMoisture100cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'cipSoilMoisturePrelim100cmMonthlyData',
        impersonate: 'cipSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['cipSoilMoisturePrelim100cmMonthlyData'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'cipSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['cipSoilMoisture10cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'cipSoilMoisturePrelim10cmMonthlyAnomaly',
        impersonate: 'cipSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['cipSoilMoisturePrelim10cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'cipSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['cipSoilMoisture100cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'cipSoilMoisturePrelim100cmMonthlyAnomaly',
        impersonate: 'cipSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['cipSoilMoisturePrelim100cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'cipSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['cipSoilMoisture10cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'cipSoilMoisturePrelim10cmMonthlyPctn',
        impersonate: 'cipSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['cipSoilMoisturePrelim10cmMonthlyPctn'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'cipSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['cipSoilMoisture100cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'cipSoilMoisturePrelim100cmMonthlyPctn',
        impersonate: 'cipSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['cipSoilMoisturePrelim100cmMonthlyPctn'],
      },
    ],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // ETA
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_dekad_median'],
    },
    overlays: ['cipEtaDekadalData'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['cipEtaDekadalPctn'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_month_median'],
    },
    overlays: ['cipEtaMonthlyData'],
    boundaries: ['cipAdmin1', 'cipAdmin2', 'cipCropzones', 'cipFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['cipEtaMonthlyPctn'],
    boundaries: ['cipAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  /**
   * Middle East
   */
  // CHIRPS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalData',
        timeseriesSourceLayerIds: ['meChirpsPentadalData'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalPrelimData',
        impersonate: 'meChirpsPentadalData',
        timeseriesSourceLayerIds: ['meChirpsPentadalPrelimData'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalGEFs5Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'meChirpsPentadalData',
        timeseriesSourceLayerIds: ['meChirpsPentadalGEFs5Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalGEFs10Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'meChirpsPentadalData',
        timeseriesSourceLayerIds: ['meChirpsPentadalGEFs10Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalGEFs15Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'meChirpsPentadalData',
        timeseriesSourceLayerIds: ['meChirpsPentadalGEFs15Data'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['meChirpsPentadalAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalPrelimAnomaly',
        impersonate: 'meChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['meChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['meChirpsPentadalZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalPrelimZscore',
        impersonate: 'meChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['meChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsMonthlyData',
        timeseriesSourceLayerIds: ['meChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirpsMonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'meChirpsMonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['meChirpsMonthlyPrelimData'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsMonthlyAnomaly',
        timeseriesSourceLayerIds: ['meChirpsMonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirpsMonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'meChirpsMonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['meChirpsMonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsMonthlyZscore',
        timeseriesSourceLayerIds: ['meChirpsMonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirpsMonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'meChirpsMonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['meChirpsMonthlyPrelimZscore'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps2MonthlyData',
        timeseriesSourceLayerIds: ['meChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirps2MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'meChirps2MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['meChirps2MonthlyPrelimData'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps2MonthlyAnomaly',
        timeseriesSourceLayerIds: ['meChirps2MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirps2MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'meChirps2MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['meChirps2MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps2MonthlyZscore',
        timeseriesSourceLayerIds: ['meChirps2MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirps2MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'meChirps2MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['meChirps2MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps3MonthlyData',
        timeseriesSourceLayerIds: ['meChirps3MonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirps3MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'meChirps3MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['meChirps3MonthlyPrelimData'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps3MonthlyAnomaly',
        timeseriesSourceLayerIds: ['meChirps3MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirps3MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'meChirps3MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['meChirps3MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps3MonthlyZscore',
        timeseriesSourceLayerIds: ['meChirps3MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'meChirps3MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'meChirps3MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['meChirps3MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // CHIRPS Prelim
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      // only applicable if there is a mean for the periodicity
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalPrelimData',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'meChirpsPentadalData',
        timeseriesSourceLayerIds: ['meChirpsPentadalPrelimData'],
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        // dataType refers to the type of data we are requesting.
        dataType: 'annual_gefs',
        // dataRoot refers to the raster name in the config endpoint
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalPrelimAnomaly',
        impersonate: 'meChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['meChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsPentadalPrelimZscore',
        impersonate: 'meChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['meChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsMonthPrelimData',
        impersonate: 'meChirpsMonthData',
        timeseriesSourceLayerIds: ['meChirpsMonthPrelimData'],
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsMonthPrelimAnomaly',
        impersonate: 'meChirpsMonthAnomaly',
        timeseriesSourceLayerIds: ['meChirpsMonthPrelimAnomaly'],
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirpsMonthPrelimZscore',
        impersonate: 'meChirpsMonthZscore',
        timeseriesSourceLayerIds: ['meChirpsMonthPrelimZscore'],
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps2MonthPrelimData',
        impersonate: 'meChirps2MonthData',
        timeseriesSourceLayerIds: 'meChirps2MonthPrelimData',
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps2MonthPrelimAnomaly',
        impersonate: 'meChirps2MonthAnomaly',
        timeseriesSourceLayerIds: 'meChirps2MonthPrelimAnomaly',
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps2MonthPrelimZscore',
        impersonate: 'meChirps2MonthZscore',
        timeseriesSourceLayerIds: 'meChirps2MonthPrelimZscore',
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps3MonthPrelimData',
        impersonate: 'meChirps3MonthData',
        timeseriesSourceLayerIds: 'meChirps3MonthPrelimData',
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps3MonthPrelimAnomaly',
        impersonate: 'meChirps3MonthAnomaly',
        timeseriesSourceLayerIds: 'meChirps3MonthPrelimAnomaly',
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'meChirps3MonthPrelimZscore',
        impersonate: 'meChirps3MonthZscore',
        timeseriesSourceLayerIds: 'meChirps3MonthPrelimZscore',
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // FLDAS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['fldas-runoff-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'meFldasMonthlyData',
        timeseriesSourceLayerIds: ['meFldasMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'mePrelimFldasMonthlyData',
        impersonate: 'meFldasMonthlyData',
        timeseriesSourceLayerIds: ['mePrelimFldasMonthlyData'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'meFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['meFldasMonthlyAnom'],
      },
      {
        type: 'single',
        forLayerId: 'mePrelimFldasMonthlyAnom',
        impersonate: 'meFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['mePrelimFldasMonthlyAnom'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // LST_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_dekad_mean'],
    },
    overlays: ['meLstC6DekadalData'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['meLstC6DekadalAnomaly'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['meLstC6DekadalZscore'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_month_mean'],
    },
    overlays: ['meLstC6MonthlyData'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['meLstC6MonthlyAnomaly'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['meLstC6MonthlyZscore'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_2month_mean'],
    },
    overlays: ['meLstC62MonthlyData'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['meLstC62MonthlyAnomaly'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['meLstC62MonthlyZscore'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_3month_mean'],
    },
    overlays: ['meLstC63MonthlyData'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['meLstC63MonthlyAnomaly'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['meLstC63MonthlyZscore'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // NDVI_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['emodisndvic6v2-2003-2017_asia_dekad_median'],
      normalizer: 'normalizeG5Data',
    },
    overlays: ['meNdvic6DekadalData'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      staticSeasonNames: ['emodisndvic6v2-2003-2017_asia_dekad_median'],
      normalizer: 'normalizeG5Data',
    },
    overlays: ['meNdvic6DekadalAnomaly'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['meNdvic6DekadalPctn'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_asia_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_asia_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // EVIIRS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['eviirsndvi-2012-2021_asia_pentad_mean'],
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_asia_pentad_data'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_asia_pentad_anom'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['eviirsndvi_asia_pentad_pctm'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_asia_pentad_pctm.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_asia_pentad_pctm.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // SWE
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/sum/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSnowData',
    },
    overlays: ['meSWEDailyData'],
    boundaries: ['meIraqBasins'],
    boundaryLabels: ['Iraq Basins'],
    chartTypes: [
      {
        graphTypes: ['line'],
        dataType: 'minmax',
        dataRoot: 'swe_asia_day_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/sum/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSnowData',
    },
    overlays: ['meSWEDailyData'],
    boundaries: ['meIraqGaugeBasinsKadaheyeh', 'meIraqGaugeBasinsKeban', 'meIraqGaugeBasinsMosul'],
    boundaryLabels: ['Kadaheyeh Gauge Basin', 'Keban Gauge Basin', 'Mosul Gauge Basin'],
    chartTypes: [
      {
        graphTypes: ['line'],
        dataType: 'minmax',
        dataRoot: 'swe_asia_day_data.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // Soil Moisture
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-10cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'meSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['meSoilMoisture10cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'meSoilMoisturePrelim10cmMonthlyData',
        impersonate: 'meSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['meSoilMoisturePrelim10cmMonthlyData'],
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-100cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'meSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['meSoilMoisture100cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'meSoilMoisturePrelim100cmMonthlyData',
        impersonate: 'meSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['meSoilMoisturePrelim100cmMonthlyData'],
      },
    ],
    boundaries: ['meAdmin1', 'meAdmin2', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'meSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['meSoilMoisture10cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'meSoilMoisturePrelim10cmMonthlyAnomaly',
        impersonate: 'meSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['meSoilMoisturePrelim10cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'meSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['meSoilMoisture100cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'meSoilMoisturePrelim100cmMonthlyAnomaly',
        impersonate: 'meSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['meSoilMoisturePrelim100cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'meSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['meSoilMoisture10cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'meSoilMoisturePrelim10cmMonthlyPctn',
        impersonate: 'meSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['meSoilMoisturePrelim10cmMonthlyPctn'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'meSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['meSoilMoisture100cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'meSoilMoisturePrelim100cmMonthlyPctn',
        impersonate: 'meSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['meSoilMoisturePrelim100cmMonthlyPctn'],
      },
    ],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // ETA
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_dekad_median'],
    },
    overlays: ['meEtaDekadalData'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['meEtaDekadalPctn'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_month_median'],
    },
    overlays: ['me'],
    boundaries: ['meAdmin1', 'meAdmin2', 'meCropzones', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['meEtaMonthlyPctn'],
    boundaries: ['meAdmin1', 'yemenCropzones', 'yemenAdmin2', 'meFNMU'],
    boundaryLabels: ['Admin 1', 'Yemen Crop Zones', 'Yemen Admin 2', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  /*
   * South America
   */
  // CHIRPS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalData',
        timeseriesSourceLayerIds: ['saChirpsPentadalData'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalPrelimData',
        impersonate: 'saChirpsPentadalData',
        timeseriesSourceLayerIds: ['saChirpsPentadalPrelimData'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalGEFs5Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'saChirpsPentadalData',
        timeseriesSourceLayerIds: ['saChirpsPentadalGEFs5Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalGEFs10Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'saChirpsPentadalData',
        timeseriesSourceLayerIds: ['saChirpsPentadalGEFs10Data'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalGEFs15Data',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'saChirpsPentadalData',
        timeseriesSourceLayerIds: ['saChirpsPentadalGEFs15Data'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['saChirpsPentadalAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalPrelimAnomaly',
        impersonate: 'saChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['saChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['saChirpsPentadalZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalPrelimZscore',
        impersonate: 'saChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['saChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsMonthlyData',
        timeseriesSourceLayerIds: ['saChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirpsMonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'saChirpsMonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['saChirpsMonthlyPrelimData'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsMonthlyAnomaly',
        timeseriesSourceLayerIds: ['saChirpsMonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirpsMonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'saChirpsMonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['saChirpsMonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsMonthlyZscore',
        timeseriesSourceLayerIds: ['saChirpsMonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirpsMonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'saChirpsMonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['saChirpsMonthlyPrelimZscore'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps2MonthlyData',
        timeseriesSourceLayerIds: ['saChirpsMonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirps2MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'saChirps2MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['saChirps2MonthlyPrelimData'],
      },
    ],
    boundaries: ['saAdmin1', 'cipAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps2MonthlyAnomaly',
        timeseriesSourceLayerIds: ['saChirps2MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirps2MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'saChirps2MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['saChirps2MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps2MonthlyZscore',
        timeseriesSourceLayerIds: ['saChirps2MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirps2MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'saChirps2MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['saChirps2MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps3MonthlyData',
        timeseriesSourceLayerIds: ['saChirps3MonthlyData'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirps3MonthlyPrelimData',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'saChirps3MonthlyData',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['saChirps3MonthlyPrelimData'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps3MonthlyAnomaly',
        timeseriesSourceLayerIds: ['saChirps3MonthlyAnomaly'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirps3MonthlyPrelimAnomaly',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'saChirps3MonthlyAnomaly',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['saChirps3MonthlyPrelimAnomaly'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps3MonthlyZscore',
        timeseriesSourceLayerIds: ['saChirps3MonthlyZscore'],
      },
      {
        type: 'gefs',
        forLayerId: 'saChirps3MonthlyPrelimZscore',
        // When building the configuration for the chart for this layer, impersonate this layer.
        impersonate: 'saChirps3MonthlyZscore',
        // Determines the 'seasons' -- the years for both layers are combined.
        timeseriesSourceLayerIds: ['saChirps3MonthlyPrelimZscore'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // CHIRPS Prelim
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      // only applicable if there is a mean for the periodicity
      staticSeasonNames: ['chirps-2000-2018_global_pentad_mean'],
      normalizer: 'normalizeGefsData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalPrelimData',
        // Impersonate this layer becuase we want the final data as well.
        impersonate: 'saChirpsPentadalData',
        timeseriesSourceLayerIds: ['saChirpsPentadalPrelimData'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        // dataType refers to the type of data we are requesting.
        dataType: 'annual_gefs',
        // dataRoot refers to the raster name in the config endpoint
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative_gefs',
        dataRoot: 'chirps-prelim_global_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalPrelimAnomaly',
        impersonate: 'saChirpsPentadalAnomaly',
        timeseriesSourceLayerIds: ['saChirpsPentadalPrelimAnomaly'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps-prelim_global_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsPentadalPrelimZscore',
        impersonate: 'saChirpsPentadalZscore',
        timeseriesSourceLayerIds: ['saChirpsPentadalPrelimZscore'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps-prelim_global_pentad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsMonthPrelimData',
        impersonate: 'saChirpsMonthData',
        timeseriesSourceLayerIds: ['saChirpsMonthPrelimData'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsMonthPrelimAnomaly',
        impersonate: 'saChirpsMonthAnomaly',
        timeseriesSourceLayerIds: ['saChirpsMonthPrelimAnomaly'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirpsMonthPrelimZscore',
        impersonate: 'saChirpsMonthZscore',
        timeseriesSourceLayerIds: ['saChirpsMonthPrelimZscore'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_2month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps2MonthPrelimData',
        impersonate: 'saChirps2MonthData',
        timeseriesSourceLayerIds: 'saChirps2MonthPrelimData',
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps2MonthPrelimAnomaly',
        impersonate: 'saChirps2MonthAnomaly',
        timeseriesSourceLayerIds: 'saChirps2MonthPrelimAnomaly',
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps2MonthPrelimZscore',
        impersonate: 'saChirps2MonthZscore',
        timeseriesSourceLayerIds: 'saChirps2MonthPrelimZscore',
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['chirps-2000-2018_global_3month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps3MonthPrelimData',
        impersonate: 'saChirps3MonthData',
        timeseriesSourceLayerIds: 'saChirps3MonthPrelimData',
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps3MonthPrelimAnomaly',
        impersonate: 'saChirps3MonthAnomaly',
        timeseriesSourceLayerIds: 'saChirps3MonthPrelimAnomaly',
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'chirps_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'gefs',
        forLayerId: 'saChirps3MonthPrelimZscore',
        impersonate: 'saChirps3MonthZscore',
        timeseriesSourceLayerIds: 'saChirps3MonthPrelimZscore',
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'chirps_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // FLDAS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['fldas-runoff-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'saFldasMonthlyData',
        timeseriesSourceLayerIds: ['saFldasMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'saPrelimFldasMonthlyData',
        impersonate: 'saFldasMonthlyData',
        timeseriesSourceLayerIds: ['saPrelimFldasMonthlyData'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'saFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['saFldasMonthlyAnom'],
      },
      {
        type: 'single',
        forLayerId: 'saPrelimFldasMonthlyAnom',
        impersonate: 'saFldasMonthlyAnom',
        timeseriesSourceLayerIds: ['saPrelimFldasMonthlyAnom'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'fldas-runoff_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // LST_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_dekad_mean'],
    },
    overlays: ['saLstC6DekadalData'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['saLstC6DekadalAnomaly'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['saLstC6DekadalZscore'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_dekad_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_month_mean'],
    },
    overlays: ['saLstC6MonthlyData'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['saLstC6MonthlyAnomaly'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['saLstC6MonthlyZscore'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_2month_mean'],
    },
    overlays: ['saLstC62MonthlyData'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['saLstC62MonthlyAnomaly'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['saLstC62MonthlyZscore'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_2month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['lstc6-2002-2018_global_3month_mean'],
    },
    overlays: ['saLstC63MonthlyData'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['saLstC63MonthlyAnomaly'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['saLstC63MonthlyZscore'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'lstc6_global_3month_zscore.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // NDVI_C6
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['emodisndvic6v2-2003-2017_southamerica_dekad_median'],
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_southamerica_dekad_data'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_southamerica_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_southamerica_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeG5Data',
    },
    overlays: ['emodisndvic6v2_southamerica_dekad_anom'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_southamerica_dekad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_southamerica_dekad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['emodisndvic6v2_southamerica_dekad_pctn'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'emodisndvic6v2_southamerica_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'emodisndvic6v2_southamerica_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // EVIIRS
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['eviirsndvi-2012-2021_southamerica_pentad_mean'],
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_southamerica_pentad_data'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_southamerica_pentad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_southamerica_pentad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
      normalizer: 'normalizeNDVI10DayCompositeData',
    },
    overlays: ['eviirsndvi_southamerica_pentad_anom'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_southamerica_pentad_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_southamerica_pentad_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: ['eviirsndvi_southamerica_pentad_pctm'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'eviirsndvi_southamerica_pentad_pctm.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'eviirsndvi_southamerica_pentad_pctm.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // Soil Moisture
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-10cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'saSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['saSoilMoisture10cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'saSoilMoisturePrelim10cmMonthlyData',
        impersonate: 'saSoilMoisture10cmMonthlyData',
        timeseriesSourceLayerIds: ['saSoilMoisturePrelim10cmMonthlyData'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-10cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['soilmoisture-0-100cm-1982-2011_global_month_mean'],
      normalizer: 'normalizeSoilMoistureData',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'saSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['saSoilMoisture100cmMonthlyData'],
      },
      {
        type: 'single',
        forLayerId: 'saSoilMoisturePrelim100cmMonthlyData',
        impersonate: 'saSoilMoisture100cmMonthlyData',
        timeseriesSourceLayerIds: ['saSoilMoisturePrelim100cmMonthlyData'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual_prelim',
        dataRoot: 'soilmoisture-0-100cm_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'saSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['saSoilMoisture10cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'saSoilMoisturePrelim10cmMonthlyAnomaly',
        impersonate: 'saSoilMoisture10cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['saSoilMoisturePrelim10cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'saSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['saSoilMoisture100cmMonthlyAnomaly'],
      },
      {
        type: 'single',
        forLayerId: 'saSoilMoisturePrelim100cmMonthlyAnomaly',
        impersonate: 'saSoilMoisture100cmMonthlyAnomaly',
        timeseriesSourceLayerIds: ['saSoilMoisturePrelim100cmMonthlyAnomaly'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_anom.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'saSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['saSoilMoisture10cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'saSoilMoisturePrelim10cmMonthlyPctn',
        impersonate: 'saSoilMoisture10cmMonthlyPctn',
        timeseriesSourceLayerIds: ['saSoilMoisturePrelim10cmMonthlyPctn'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-10cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/false',
      type: 'json',
    },
    overlays: [
      {
        type: 'single',
        forLayerId: 'saSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['saSoilMoisture100cmMonthlyPctn'],
      },
      {
        type: 'single',
        forLayerId: 'saSoilMoisturePrelim100cmMonthlyPctn',
        impersonate: 'saSoilMoisture100cmMonthlyPctn',
        timeseriesSourceLayerIds: ['saSoilMoisturePrelim100cmMonthlyPctn'],
      },
    ],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'soilmoisture-0-100cm_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },

  // ETA
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_dekad_median'],
    },
    overlays: ['saEtaDekadalData'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['saEtaDekadalPctn'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_dekad_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
      staticSeasonNames: ['etav5-2003-2017_global_month_median'],
    },
    overlays: ['saEtaMonthlyData'],
    boundaries: ['saAdmin1', 'saAdmin2', 'saCropzones', 'saFNMU'],
    boundaryLabels: ['Admin 1', 'Admin 2', 'Crop Zones', 'FNMU'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_data.data',
        yAxisRange: 'auto',
      },
    ],
  },
  {
    source: {
      url:
        'https://edcintl.cr.usgs.gov/geoengine5/rest/timeseries/version/5.0/vector_dataset/{{vector_dataset}}/raster_dataset/{{raster_dataset}}/periodicity/{{periodicity}}/statistic/{{statistic}}/lat/{{lat}}/lon/{{lon}}/seasons/{{seasons}}/zonal_stat_type/mean/mean-median/true',
      type: 'json',
    },
    overlays: ['saEtaMonthlyPctn'],
    boundaries: ['saAdmin1', 'saAdmin2'],
    boundaryLabels: ['Admin 1', 'Admin 2'],
    chartTypes: [
      {
        graphTypes: ['bar', 'line'],
        dataType: 'annual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['bar', 'line'],
        dataType: 'interannual',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
      {
        graphTypes: ['line', 'bar'],
        dataType: 'annual_cumulative',
        dataRoot: 'etav5_global_month_pctn.data',
        yAxisRange: 'auto',
      },
    ],
  },
];
