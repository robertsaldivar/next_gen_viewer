export const periods = {};
