export const regions = [
  {
    id: 'us',
    name: 'usa',
    title: 'U.S.',
    srs: 'EPSG:3857',
    bbox: [-1.4309383410780452e7, 2568806.969686844, -7279393.751639449, 6760229.116087286],
    comments: '',
  },
];
