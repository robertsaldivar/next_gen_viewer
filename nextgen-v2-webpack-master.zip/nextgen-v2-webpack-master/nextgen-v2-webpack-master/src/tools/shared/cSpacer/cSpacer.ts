// '->' is shorthand for the Ext.Toolbar.Fill class
// https://extjs.cachefly.net/ext-3.2.0/docs/output/Ext.Toolbar.html

export const cSpacer = {
  getComponent: function (extendedTool, items, toolbar, menu) {
    return '->';
  },
};
