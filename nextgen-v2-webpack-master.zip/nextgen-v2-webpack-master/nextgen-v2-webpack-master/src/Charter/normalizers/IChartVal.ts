export interface ChartVal {
  x: string;
  y: number;
  granule_start: string;
  granule_end: string;
  value?: number;
  groupLabel?: string;
}
